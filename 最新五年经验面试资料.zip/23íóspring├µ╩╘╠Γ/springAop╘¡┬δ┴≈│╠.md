## 一、加上EnableAspectJAutoProxy注解

1、里面import了AspectJAutoProxyRegistrar 类

2、这个类先往容器中注入一个AnnotationAwareAspectJAutoProxyCreator.class

3、假如容器中已经有了相同的beanName的bd，则查看其优先级，假如这个优先级比AnnotationAwareAspectJAutoProxyCreator低，则用这个类覆盖原来的类

优先级顺序为：InfrastructureAdvisorAutoProxyCreator，AspectJAwareAdvisorAutoProxyCreator，AnnotationAwareAspectJAutoProxyCreator

4、最后设置proxyTargetClass属性和exposeProxy属性，到bd里面去

## 二、在bean实例化前，先解判断一次，哪些beanName是要代理的哪些是不要代理的

1、执行AbstractAutoProxyCreator的postProcessBeforeInstantiation

2、应不应该被代理，让advisedBeans放置beanName和布尔值

3、如果这个beanName有合适的自定义的TargetSourceCreator，把beanName添加进targetSourcedBeans

## 三、在bean初始化以后

1、执行AbstractAutoProxyCreator的postProcessAfterInitialization

2、最后会执行wrapIfNecessary

3、假如advisedBeans里面已经是false了，就返回这个bean

4、getAdvicesAndAdvisorsForBean获取所有和这个bean相关的Advisor

5、最后执行createProxy

## 四、createProxy

1、先创建proxyFactory

2、再获取JdkDynamicAopProxy或者是ObjenesisCglibAopProxy（实现了cglib），并且把proxyFactory传进去

3、最后调用JdkDynamicAopProxy的getProxy方法

4、Proxy.newProxyInstance(classLoader, proxiedInterfaces, this)会调用这个方法，在执行这个之前，会获取代理类的所有接口，根据需要，再添加一些spring自己的接口。

4、1 如果没有实现SpringProxy.class，在接口中要加入SpringProxy.class

4、2 如果没有实现Advised.class并且opaque=true，则要加入这个接口

4、3 如果没有实现DecoratingProxy并且decoratingProxy=true（这里恒为true）

5、JdkDynamicAopProxy本身是一个实现了InvocationHandler的类，他会用自己织入进去，当执行代理类的方法时，都会执行都会执行invoke方法

在这里已经返回了代理类了

## 五、执行具体方法时

1、执行invoke方法，会判断是否和当前的方法匹配，如果匹配则执行增强方法

