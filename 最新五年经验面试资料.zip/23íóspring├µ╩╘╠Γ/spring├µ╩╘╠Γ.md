## 一、spring如何创建一个bean的

1、构造beanDefinition

2、依赖注入

3、然后放到单例池里面去