## 一、AnnotationConfigApplicationContext的初始化

1、顶层父类DefaultResourceLoader只是赋值了classLoader

2、AbstractApplicationContext只是加载了resourcePatternResolver

3、GenericApplicationContext创建了beanFactory = DefaultListableBeanFactory

### 3、1 DefaultListableBeanFactory里面添加了

```
ignoreDependencyInterface(BeanNameAware.class);
ignoreDependencyInterface(BeanFactoryAware.class);
ignoreDependencyInterface(BeanClassLoaderAware.class);
		在自动装配的时候忽略这3个set方法
```

4、AnnotationConfigApplicationContext 执行了

````
		this.reader = new AnnotatedBeanDefinitionReader(this);
		this.scanner = new ClassPathBeanDefinitionScanner(this);
````

### 4、1 this.reader = new AnnotatedBeanDefinitionReader(this)

1、给beanFactory赋值，AnnotationAwareOrderComparator和ContextAnnotationAutowireCandidateResolver

2、注册一些spring自带的beanDefiniation

```
ConfigurationClassPostProcessor
AutowiredAnnotationBeanPostProcessor
CommonAnnotationBeanPostProcessor
PersistenceAnnotationBeanPostProcessor（这个不一定有）
EventListenerMethodProcessor
DefaultEventListenerFactory
```

## 二、register（配置类）

1、把配置类变成beanDefination注册进去

# reflesh()

## 三、prepareRefresh（初始化context）

1、设置earlyApplicationListeners和applicationListeners，一般一开始没有值

2、earlyApplicationEvents初始化为空

3、close初始化为false，active初始化为true

## 四、obtainFreshBeanFactory

1、refreshed设置为true

2、beanFactory里面设置一个序列化id，把自己包装成WeakReference放入serializableFactories里面

3、获取beanFactory（DefaultListableBeanFactory）

## 五、prepareBeanFactory

1、忽略一些接口的set方法，不要完成自动注入，EnvironmentAware，EmbeddedValueResolverAware

2、registerResolvableDependency，把一些值放进去

3、添加一些BeanPostProcessor

3、1 ApplicationContextAwareProcessor，负责处理一些bean的接口的依赖的

3、2 ApplicationListenerDetector，假如发现一些bean继承了ApplicationListener，就把他们添加到applicationListeners和applicationEventMulticaster中

4、把environment，systemProperties，systemEnvironment 等bean添加到单例池里面去

## 六、postProcessBeanFactory

什么也没干

## 七、invokeBeanFactoryPostProcessors

BeanFactoryPostProcessor可以获取beanFactory，从里面获取bd，可以修改bd的值

BeanDefinitionRegistryPostProcessor可以获取register，可以注册bd

1、先找到BeanFactoryPostProcessors，触发postProcessBeanDefinitionRegistry方法，里面可以拿到registry，可以去注册bd，也可以修改bd的值

1、1 先找到实现了BeanDefinitionRegistryPostProcessor和PriorityOrdered的类，触发postProcessBeanDefinitionRegistry方法

1、2 再找到实现了BeanDefinitionRegistryPostProcessor和Ordered的类，触发postProcessBeanDefinitionRegistry方法

1、3 再for循环不断的执行postProcessBeanDefinitionRegistry，直到没有新的BeanDefinitionRegistryPostProcessor需要被执行

1、4 再执行BeanDefinitionRegistryPostProcessor的postProcessBeanFactory

1、5 最后再执行BeanFactoryPostProcessor的postProcessBeanFactory

## 八、这里会触发一个内置的beanFactoryPostProcessors，ConfigurationClassPostProcessor

1、processConfigBeanDefinitions会for循环的，类似递归，不断解析出配置类，再把配置类又放回去解析

2、这里认为Component，ComponentScan，Import，ImportResource都是配置类，都需要解析

3、如果是Component注解，就解析他的内部类

4、如果是ComponentScans和ComponentScan，就解析里面的包，并且扫描里面的类，解析出来以后，如果还是配置类，就再次解析

5、如果是Import，就解析import

5、1 解析ImportSelector.class

5、2 解析 ImportBeanDefinitionRegistrar.class

5、3 把他当成一个普通的配置类来解析，也把他加入到bd中

5、4 @ImportResource(locations = {"classpath:beans.xml"})，解析配置类

5、5 解析@Bean方法，解析成BeanMethod加入到beanMethods

## 九、registerBeanPostProcessors

1、获取所有BeanPostProcessor的beanName，分成4组priorityOrderedPostProcessors，internalPostProcessors，orderedPostProcessorNames，nonOrderedPostProcessorNames

2、先注册一个BeanPostProcessorChecker，假如有非BeanPostProcessor的bean在BeanPostProcessor实例化中被实例出来了，就会走入这个判断，这个bean如果没有经过所有的beanPostProcessor，就会打印日志告警

3、如果他实现了PriorityOrdered，会优先实例化调用getBean方法，把他放到beanPostProcessors里面去

4、假如里面有实现了MergedBeanDefinitionPostProcessor，就把他加入internalPostProcessors

5、再getBean这个orderedPostProcessorNames，放入beanPostProcessors里面去

6、再getBean这个nonOrderedPostProcessorNames，放入beanPostProcessors里面去

7、最后重新注册internalPostProcessors，把这个放在最后面，顺序上，这个是最后面

## 十、getBean方法

1、AbstractBeanFactory的doGetBean

2、先从单例池里面取，取不到再去创建

3、创建首先会将本bean的bd和父类的bd都取到，然后用父类new 一个RootBeanDefiniation，再用子类的bd覆盖里面的值，最后用这个合并的bd去干活

4、调用getSingleton方法

5、getSingleton里面，标识bean正在创建singletonsCurrentlyInCreation.add，最后调用singletonFactory的getObject，其实就是调用了外面的

## 十一、createBean

1、先根据beanName设置class

2、调用resolveBeforeInstantiation，如果这里可以返回bean就不再往下走了

2、1 InstantiationAwareBeanPostProcessor里面会调用postProcessBeforeInstantiation，如果得到了bean，再调用postProcessAfterInstantiation，然后直接返回了

3、如果上面方法得不到bean则调用doCreateBean

## 十一、doCreateBean

### 一、对象实例化

1、调用createBeanInstance

1、1 如果有supplier，则调用supplier的方法来创建

1、2 如果有工厂方法则，调用工厂方法来创建

1、3 不然就推断构造方法

1、4 如果没有找到就用无参构造

### 二、对象的赋值 populateBean

做一些准工作

1、applyMergedBeanDefinitionPostProcessors，执行MergedBeanDefinitionPostProcessor的方法，spring内置的有3个

1、1 CommonAnnotationBeanPostProcessor 获取一个类所有的InjectionMetadata缓存起来，找到所有@Resource的成员变量

1、2 父类是InitDestroyAnnotationBeanPostProcessor获取LifecycleMetadata缓存起来，找到所有的InitAnnotationType（@PostConstruct）放入currInitMethods和destroyAnnotationType（@PreDestroy）放入currDestroyMethods，然后再放入bd的externallyManagedInitMethods和externallyManagedDestroyMethods里面

1、3 AutowiredAnnotationBeanPostProcessor 获取一个类所有的自动注入的metaData缓存起来，找到所有@Autowired和@Value的成员变量，缓存起来

1、4 ApplicationListenerDetector 获取一个类的是否是单例 放置在 singletonNames (map\<beanName,是否是单例\>)中

2、如果允许循环依赖，addSingletonFactory，先往singletonFactories里面放singletonFactory（假如是aop，则是AbstractAutoProxyCreator），本质上是调用SmartInstantiationAwareBeanPostProcessor的getEarlyBeanReference方法，而AbstractAutoProxyCreator实现了这个方法，会返回一个aop对象出来赋值

3、autowritebyName和autowriteByBean，先去找其他的依赖的bean，如果需要会进一步createBean

4、先调用filterPropertyDescriptorsForDependencyCheck，过滤掉一些，一开始被指定了忽略的属性

5、调用postProcessProperties，本质上是调用了AutowiredAnnotationBeanPostProcessor 和 CommonAnnotationBeanPostProcessor 的 postProcessProperties，处理属性依赖，然后真的把值注入进去

6、赋值完了再次检查确认，那些过滤器的接口是否确实没有被赋值

7、applyPropertyValues，通过beanDefinition注入

### 三、对象的初始化initializeBean

1、执行invokeAwareMethods方法，设置setBeanName，setBeanClassLoader，setBeanFactory

2、执行postProcessBeforeInitialization

2、1 执行CommonAnnotationBeanPostProcessor的父类InitDestroyAnnotationBeanPostProcessor的执行@PostConstructor的方法

3、invokeInitMethods

3、1 执行afterPropertiesSet方法 

3、2 invokeCustomInitMethod执行init-method方法

4、最后执行postProcessAfterInitialization

### 四、注册disposableBeans

## 十二、initMessageSource

处理国际化的

## 十三、initApplicationEventMulticaster

1、如果beanFactory里面有applicationEventMulticaster，就getBean实例化出来

2、如果没有，就注册一个进去

## 十四、onRefresh

啥也没干

## 十五、registerListeners

往applicationEventMulticaster里面放置监听器

## 十六、finishBeanFactoryInitialization

1、把ConversionService放入容器中

2、添加StringValueResolver

3、先把当前的beanName固定下来，赋值给frozenBeanDefinitionNames

4、preInstantiateSingletons，这里对所有的beanname进行getBean

4、1 对象实例化

4、2 对象赋值

4、3 对象初始化

5、如果实现了SmartInitializingSingleton，最后还会执行afterSingletonsInstantiated方法

## 十七、finishRefresh

1、清空clearResourceCaches

2、赋值一个LifecycleProcessor

3、调用LifecycleProcessor的onRefresh方法

3、1 获取所有实现了Lifecycle的bean

3、2 遍历Lifecycle的bean，如果是SmartLifecycle的bean就获取其phase，将其按照phase分组

3、3 最后按照phase从小到大排序，依次调用start方法

4、最后发布ContextRefreshedEvent事件，会被ApplicationListener监听到

5、最后把LiveBeansView注册到MBeanServer里面去，让jmx可以查看，再把applicationContext放入LiveBeansView里面的一个set中

## 十九、application.close

1、发布ContextClosedEvent事件

2、执行Lifecycle的bean的stop方法

3、执行实现了DisposableBean的bean的destroy方法

4、然后是清空各个缓存

5、onClose方法，什么也没干

6、清空监听器

7、active设置为false

