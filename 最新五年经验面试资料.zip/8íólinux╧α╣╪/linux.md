## 一、bash是什么

1、bash是一个命令处理器，运行在文本窗口中，能够执行用户的命令

2、可以从文件中读取linux命令，称之为脚本

3、bash支持通配符、管道、命令替换、条件判断

-i参数是表示询问确认的意思

alias 可以查看一些命令的别名

alias ll='ls -l --color=auto'

！！重复执行上一次的命令

！数字，重复执行某一次的命令

## 二、快捷键

ctrl + a 到开头

ctrl + e 到结尾

ctrl + k 删掉光标后

ctrl +u 删掉光标前

## 三、介绍

grep：文本过滤工具

sed：stream editor，流编辑器

awk：Linux文本报告生成器（格式化文本）其实是软连接本质是gawk

## 四、Linux的正则表达式分为2类

基本正则表达式

BRE：^$.[]*

扩展正则表达式

ERE在BRE基础上，增加上(){}?+|等字符

1、普通的正则可以直接用grep

2、扩展正则可以用grep -E才能生效

## 五、sed

字符流编辑器

1、一次读取一行数据

2、读取到的数据会到自己的模式空间

3、模式匹配

4、匹配失败直接输出（可以取消这个的输出）

5、匹配成功执行修改，然后再输出

## 六、sed的用法

sed  选项 "[范围]内置命令符"   输入文件

选项：

-n ：取消默认sed的输出，常与sed内置命令一起使用

-i：直接将结果写回文件，不用-i，sed修改的是内存的数据

-e：多次编辑，不需要管道符了

-r：支持正则扩展

内置命令字符：

a：对文本追加

d：delete删除匹配行

i：insert表示插入文本

p：print打印匹配行的内容

s/正则/替换内容/g：结尾g代表全局匹配

sed匹配范围

空：全文处理

单地址：指定文件某一行

/pattern/：被模式匹配到的行

范围区间：10,20  十到二十行，10，+5 第十行向下5行

步长：1~2从1开始2行取一次  1,3,5,7,9，

2~2表示从第二行开始2行取一次  2,4,6,8

## 七、sed案例

```
cat -n test.txt
1  My name is chaoge
2  I teach linux
3  I like play computer game
4  My qq is 84546
5  My website is http://fdafa

```

1、输出第2,3行的内容

sed   "2,3p" text.txt -n test.txt

2、打印含有linux的行

sed   "/linux/p"  -n test.txt

3、删除含有linux的行，并打印

sed  "/linux/d"  test.txt   -- 利用了默认输出

4、删除含有linux的行，并写回文件

sed "/linux/d"  test.txt  -i 

5、从第5行一直删除到结尾 

sed  "5,$d"  test.txt -i

6、将文件中的my替换为 his

sed   "s/my/his/g" text.txt  

sed    "s#my#his#g" text.txt

sed    ""s@my@his@g"  text.txt

7、多次替换

sed  -e  "s/I/My/g"  -e  "s/8888/100/g"  test.txt

8、在第二行后面追加一行

sed  "2a  My linux is good." test.txt -i

9、在前一行写入

sed  "2i  My linux is good." test.txt -i

10、在每一行下面都加上“---”

sed  "a  ----" test.txt -i

11、打印出 ifconfig eth0的ip地址

ifconfig eth0 | sed -e "2s/^.\*inet//" -e "2s/netmask.\*$//p"  -n

## 八、awk

用来做文本格式化

awk语法：

```
awk [option] 'pattern[action]' file
```

### 1、awk文本格式化

例子：

1、打印第一列

awk  '{print $1}' test.txt

2、打印全部

awk  '{print $0}' test.txt

3、awk的内置变量

$n：指定分隔符后，当前记录的第n个字段

$0：完整的输入记录

FS：字段分隔符，默认是空格

OFS：输出分割符，print  \$1,\$2，会默认以空格进行分割，修改以后可以是别的符号

NF（Number of fields）：分割后，当前一共多少个字段

NR（Number of records）：当前行号，用法：NR==5

RS   输入记录分隔符（输入换行符），指定输入时的换行符

ORS  输出记录分隔符（输出换行符），输出时用的指定的换行符

FNR：各文件分别计数的行号

FILENAME：当前文件名

ARGC：命令参数的个数

ARGV：数组，保存的是命令行所指定的各参数（[awk命令,文件名]）

更多内置变量可以查看：man awk

3、一次输出多列

awk  '{print \$1 \$2}' test.txt

4、插入列

awk  '{print "第一列",\$1,"第二列",\$2,"第三列",\$3}' test.txt

5、默认输出

awk '{print }' 什么都不加

6、打印某一行

awk  'NR==5{print $0}' change.txt

7、打印3到6行

awk   'NR==3,NR==6'   change.txt

8、给每行内容加上行号

awk  '{print  NR,$0}' change.txt

9、输出倒数第二列

awk '{print \$1,\$(NF-1)}' change.txt

### 2、awk变量

1、按照冒号来分割

-F指定分割符

awk -F ":"  "{print $i}" pwd.txt

-v 修改变量

awk  -v FS=":"  "{print $i}"  pwd.txt

 2、显示的时候用 ===作为分割符

awk  -F  ":" -v  OFS="==="  {print \$1,$NF} pwd.txt

3、同时输出两个文件

awk  '{print FNR,$0}' change.txt   luffy.txt

FNR（代表文件里面的行号）

4、BEGIN模式

awk  'BEGIN{print "超哥开始用awk了"}{print ARGV[0],ARGV[1],ARGV[2]}' change.txt

5、自定义变量

awk -v  aaa='超哥'  '{print aaa}'

6、间接引用shell变量

aa = '超哥'

awk  -v  bb=aa  '{print bb}'

### 3、awk格式化输出

1、介绍printf

awk '{print $0}' test.txt 默认是加上换行符的

awk  '{printf $0}' test.txt  默认是没有换行符的

awk  '{printf  "%s\\n",$0}' 可以带上换行符

2、每列前面都加上点文字

awk  '{printf  "第一列:%s  第二列:%s   第三列:%s",\$1,\$2,\$3}' test.txt

