## 一、ApiServer

1、向master发送CommandType.STATE_EVENT_REQUEST

## 二、StateEventProcessor

1、Master的StateEventProcessor收到请求

2、新建一个stateEvent，是TASK_STATE_CHANGE，放入eventQueue

## 三、StateEventResponseWorker

1、取出stateEvent

2、取出WorkflowExecuteThread，放入stateEvent

## 四、StateWheelExecuteThread（一直不断循环）

1、一直检查startProcessFailedMap有没有WorkflowExecuteThread，如果有就拿出来重新执行

2、一直检查taskInstanceTimeoutCheckList，有没有设置了超时的task，如果有查看一下剩余时间是多少，如果超时，添加一个TASK_TIMEOUT事件到WorkflowExecuteThread里面去，移除taskInstanceTimeoutCheckList

3、一直检查taskInstanceRetryCheckList有没有taskInstance，如果有判断是否完成了，如果完成了，添加一个TASK_STATE_CHANGE，放入eventQueue

4、一直检查processInstanceTimeoutCheckList，判断process是否超时，如果超时了，添加一个TASK_TIMEOUT事件到WorkflowExecuteThread里面去，移除taskInstanceTimeoutCheckList

## 五、EventExecuteService

1、不断的去遍历processInstanceExecMaps，拿出event不为空的WorkflowExecuteThread

2、把WorkflowExecuteThread放入eventHandlerMap

3、然后再次提交执行WorkflowExecuteThread

4、如果执行成功的话，

4、1 判断task是否完成，如果完成了就移除processInstanceExecMaps

4、2 eventHandlerMap移除这个workflowExecuteThread

4、3 添加TASK_STATE_CHANGE到workflowExecuteThread

## 六、WorkflowExecuteThread处理Event

1、stateEventHandler

2、重点先看PROCESS_STATE_CHANGE，processStateChangeHandler

3、如果是READY_STOP，就killAllTasks()

4、从activeTaskProcessorMaps中，找到正在执行的task

5、ITaskProcessor提交STOP，最后向worker发送killCommand，netty向worker发送TASK_KILL_REQUEST

-- 6、如果是Stop，就updateProcessInstanceState，更细数据库t_ds_process_instance的状态

6、最后添加一个ACTION_STOP 的Event到eventQueue里面去

7、最后会执行TaskResponsePersistThread，里面的ACTION_STOP 分支，修改t_ds_processInstance任务状态为kill

## 七、TaskKillResponseProcessor

1、添加一个TaskResponseEvent到eventQueue，一般是SUCESS，Event是ACTION_STOP

2、从WorkflowExecuteThread中取出ITaskProcessor，执行taskProcessor.persist(TaskAction.STOP)

3、修改t_ds_task_instance的状态

4、发送TASK_KILL_RESPONSE_ACK给worker