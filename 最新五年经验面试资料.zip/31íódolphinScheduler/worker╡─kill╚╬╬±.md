## 一、TaskKillProcessor

1、doKill

2、根据taskInstanceId从workerManager获取TaskExecuteThread

3、最后取出task，执行cancelApplication（有的是直接执行一个kill -9 指令）

4、移除workerExecuteQueue

5、发送TASK_EXECUTE_RESPONSE，状态是kill

6、taskRequestContextCache移除这个task

7、如果这个taskExecutionContext里面有processId，他会kill -9这个processId，这个可能也没有

8、如果kill成功了，taskRequestContextCache就没有这个taskInstanceId了，那么就发送

## 二、TaskKillAckProcessor

1、从killResponseCache移除这个taskInstanceId

2、REMOTE_CHANNELS移除这个taskInstanceId