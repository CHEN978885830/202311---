## 一、如何让任务下线

1、从Quazte中移除该任务

2、在Quazte的job里面再查询一遍上线状态，如果是下线的，就移除

## 二、如何处理粘包和拆包的

他自己实现了ReplayingDecoder，一个数据包过来，会从先读取魔术字节，再切换成读version字节，通过切换状态，使用不同的方式来读，去读以后缓存到CommandHeader中，最终读完body，再提取出commandHeader的数据，封装成一个Command

本质上ReplayingDecoder是实现了ByteToMessageDecoder，他会对未读完的数据进行缓存

## 三、master挂了如何做容错的

如果master挂了，他会有一个对zookeeper的监听，监听到数据的变化，就去拉取另外一个master节点的正在处理的process_instance，修改数据库中的数据，在发送一个host change请求给worker，worker收到请求以后，会修改自己的channelmap。

而worker所有的响应都会用一个map缓存起来，如果超时未收到master的回复，他就会遍历这些map，重新找到对应的host去发送请求

如果监听没有及时处理，他还有一个专门用于做容错的线程，定时去拉取需要容错的host

## 四、worker挂了如何容错的

如果worker挂了，master会监听到，会根据worker的任务类型，有失败继续执行和失败就结束，如果是失败就结束，直接修改processInstance的状态为失败，worker挂了他不会默认为你重试的，除非task配置了重试次数

容错线程也会处理worker的容错

## 五、协议包的结构

一个字节魔数，一个字节版本，一个字节command类型，一个字节请求id，一个long的header的context长度，然后是读byte，一个long的body长度，然后是读byte

## 六、master之间是如何协作的，如何做到去中心化

所有的Quazte调度任务，都只是负责把command插入数据库，master会监听当前有多少个master，每个master有一个排队id，每次都会从数据库里面取出master个数个task，但是只会处理index为masterid的数据

## 七、如何理解有向无环图

就是一个维护了有向线段和节点的集合，创建这个数据结构的目的，是通过一些简单的运算，让我们很方便的获取到头结点和某个节点的后续节点