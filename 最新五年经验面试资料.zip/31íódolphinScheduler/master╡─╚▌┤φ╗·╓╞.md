# Master的容错机制

## 一、ServerNodeManager的MasterDataListener

1、监听/nodes/master的变化

2、用来更新masterNodes和masterPriorityQueue，SLOT_LIST，MASTER_SIZE

## 二、ServerNodeManager的WorkerDataListener

1、监听/nodes/worker

2、用来更新workerNodeInfo和workerGroupNodes

## 三、MasterRegistryDataListener的master容错

1、监听/nodes，只处理remove事件

2、假如master节点发生变化，master挂了

3、加上failover分布式锁

4、添加一个节点/dead-servers/Master_host:port

5、调用去容错failoverMaster(serverHost)

5、1 获取需要容错的serverHost的serverStartupTime

5、2 获取所有worker的Server信息（包含部分心跳信息）

5、3 获取所有需要容错的ProcessInstance

5、4 遍历这些ProcessInstance获取所有的taskInstance

5、5 判断taskInstance是否需要容错（判断这些task的提交时间，是否在worker启动前，也就是worker是否被重启过，如果worker重启过，task的状态改为NEED_FAULT_TOLERANCE，如果没有被重启过，task的状态还是isRunning）

5、6 kill yarn job

5、7 更新taskInstance的状态为需要容错

6、对processInstance容错

6、1 更新t_ds_process_instance的host为null

6、2 创建一个Command为RECOVER_TOLERANCE_FAULT_PROCESS

## 四、MasterSchedulerService处理Command

1、获取processInstance，因为数据库中可以找到所以不用新建

2、新建一个WorkflowExecuteThread放入processInstanceExecMaps，并执行

3、WorkflowExecuteThread生成DAG有向无环图

4、根据processInstance找到，找到taskInstance，过滤掉已经执行成功的taskInstance，获取未执行成功的taskInstance，这些可能是未提交状态成功，我们也认为他未成功

5、如果task正在running，对那个host发送PROCESS_HOST_UPDATE_REQUEST

6、如果是其他的例如NEED_FAULT_TOLERANCE，task就会重新被提交

---注意：也就是说，如果master挂了，worker也重启过，那些那些正在运行的task是有重复执行一次的风险的

7、如果发现task全部成功了，只是instance状态未更新，就更新状态即可

## 五、FailoverExecuteThread

1、每10分钟再去扫描一下，有哪些processInstance需要容错

2、只处理现在/nodes/master上面没有的和host是自己的

3、在处理的时候加上分布式锁，确保每个processInstance容错只被处理一次

4、后续就是和MasterRegistryDataListener一样的流程

## 六、MasterRegistryDataListener的worker容错

1、监听/nodes，只处理remove事件

2、假如worker节点发生变化，worker挂了，放入/dead-servers里面

3、修改t_ds_task_instance为NEED_FAULT_TOLERANCE

4、给WorkflowExecuteThread发布一个TASK_STATE_CHANGE的StateEvent

5、eventExecuteService获取WorkflowExecuteThread，重新提交执行，处理TASK_STATE_CHANGE

6、如果任务是可重试的，那么会往readyToSubmitTaskQueue添加这个task，taskRetryCheckList添加这个task

7、会往errorTaskList放入这个task

8、给WorkflowExecuteThread发布一个PROCESS_STATE_CHANGE的StateEvent

9、如果activeTaskProcessorMaps里面有其他任务，他会跑完其他的任务，这些任务最后都会触发PROCESS_STATE_CHANGE

10、最后会走到processFailed这个分支，根据失败策略，如果失败了就结束，他就直接让processInstance的状态置为false，如果失败了continue，那么如果任务都执行完了，他就会是一个成功的状态。

11、也就是说，worker挂了，就让这个任务挂掉，不会进行重启，除非他有什么重试策略