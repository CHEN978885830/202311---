## 一、Worker主流程

### 一、启动netty，监听12346端口

### 二、向zookeeper注册信息

1、注册一个临时节点到zookeeper

2、每10秒上报一次心跳

3、注册一个监听器，当zookeeper挂了，他自己就会停止，如果重连，则会重新注册临时节点

4、他的weight初始化为100

5、连接上告警服务器，作为一个NettyClient

## 二、启动WorkerManagerThread

1、循环的从workerExecuteQueue里面拿数据

2、拿到TaskExecuteThread以后，提交给WorkerExecService

3、WorkerExecService先把taskInstanceId和taskExecuteThread缓存到taskExecuteThreadMap

4、封装任务成ListenableFuture

5、执行完毕以后，再移除taskExecuteThreadMap

## 三、TaskExecuteThread

1、检查自己的这个节点上有没有这个租户

2、判断是否是dryRun，如果是dryRun不会去下载文件，也不会执行handle方法

3、如果不是dryRun，会去下载文件，根据type获取对应的插件

4、执行任务

5、执行完了以后，发送结果  TASK_EXECUTE_RESPONSE

6、删除TaskExecPath

## 四、TaskPluginManager

创建一个TaskPluginManager通过SPI的方式加载插件，放到一个map中去

## 五、RetryReportTaskStatusThread

## 六、TaskExecuteProcessor

1、接收TASK_EXECUTE_REQUEST的Command

2、把task请求缓存起来 taskRequestContextCache

3、创建一个工作目录/tmp/dolphinScheduler/....，如果创建失败就清楚这次task的请求缓存

4、如果任务不用延期，就把任务状态修改为running

5、ACK回应Master节点，把response请求缓存，一下

6、创建TaskExecuteThread，放入workerManger的workerExecuteQueue队列，最后由WorkerExecService提交执行

## 七、DBTaskAckProcessor

如果成功，移除response的请求缓存，打个日志，啥也不做

如果失败，什么也不做

## 八、DBTaskResponseProcessor

如果成功，移除response的请求缓存，打个日志，从REMOTE_CHANNELS移除这个taskId

如果失败，什么也不做

## 九、RetryReportTaskStatusThread

1、所有对master的report他都会缓存起来，如果发送过，会得到master的ack，得到ack再清除这个缓存

2、如果得不到ack，那么RetryReportTaskStatusThread就是定期重传，要求10秒内得到响应，如果没有响应，每10秒重传一次