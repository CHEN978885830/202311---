## 一、启动netty

启动netty，默认监听5678端口

### 二、向zookeeper注册信息

1、注册的时候加上分布式锁 /lock/failover/startup-masters

2、创建一个临时节点 /nodes/master/172.28.199.155:5678，如果节点已存在则修改其值，里面放心跳信息

3、如果这个节点在/dead-servers/172.28.199.155:5678 里面，则移除

4、添加监听器

监听 /nodes/master/172.28.199.155:5678 节点

（1）如果重连，则重新创建/nodes/master/172.28.199.155:5678 心跳节点，或者重新设置值

（2）如果断开连接，则释放资源，关闭spring和quatz之类的

5、再创建一个定时任务，每10秒上报一次心跳信息

心跳信息里面包括了

```
        // cpuUsage,memoryUsage,loadAverage,availablePhysicalMemorySize,maxCpuloadAvg,reservedMemory,startupTime,   reportTime    serverStatus
        // 0.03,    0.18,       0.82,       102.77,                     64.0,         0.3,           1663138885710, 1663170746960,0,
        // processId,workerHostWeight,workerExecThreadCount,workerWaitingTaskCount
        // 15286,       0,              0,                      0
```

6、再次添加监听器

监听/nodes节点

6、1 如果监听到Master发生了变化

（1）添加，什么也不做

（2）移除

这里也要加分布式锁

（2、1）把这个节点添加到 /dead-servers里面去

启动容错机制

（2、2）查出那个节点正在执行的任务

（2、3）把一些在挂掉的master节点上处理的任务，重新启动，放到这个master上面来

（2、4）进行master容错

6、1 如果监听到Worker发生了变化

进行worker容错

### 三、启动EventExecuteService

每隔一段时间去扫描processInstanceExecMaps。。。，因为现在processInstanceExecMaps里面还没有内容，所以先往下看

### 四、启动MasterSchedulerService

1、如果当前资源大于了限制，就先休息一下，如果当前数据库中没有command，就休息一秒

2、处理数据库的命令（因为我们要处理命令，所以我们需要先去了解一个任务是怎么定义的，怎么调度的）

3、找一个command来执行，例如有2个master，那么master就会去commandId%3=自己的slot的那节点来执行

4、根据command创建processInstance，放入t_ds_process_instance表中，然后删除command

5、将processInstance包装成WorkflowExecuteThread，提交给MasterExecService执行

6、如果中间执行发生了异常则向t_ds_error_command插入一条数据，同时也删掉command

四一、MasterExecService执行任务

1、先往filterMap放入这个processInstance的Id防止他重复执行

2、给他放置一个回调，监听其成功和失败，如果触发了回调发现还未start，则放入startProcessFailedMap中，如果成功了，则移除

3、创建一个WorkflowExecuteThread放入processInstanceExecMaps中key是processInstanceId

4、执行WorkflowExecuteThread

### 五、启动failoverExecuteThread

### 六、启动QuartzExecutors

启动一个Quartz调度器，可以往里面放scheduler.scheduleJob(jobDetail, trigger);

## 二、ServerNodeManager节点信息管理

1、启动一个单线程定时每10秒同步一次worker的信息

```
//worker node info {"host:port": "/node/worker/groupName/host:port"}
Map<String, String> workerNodeInfo = new HashMap<>();
```

2、向zookeeper注册一个监听器监听master节点的变化信息

如果是add

则更新masterNodes，更新masterPriorityQueue，更新MASTER_SIZE，更新SLOT_LIST（一般只有一个元素，就是本机在masterPriorityQueue里面的index）

如果是remove

重复add做的事情

3、向zookeeper注册一个监听器监听worker节点的变化信息

如果是某个workerpat发生了变化，那么就拉取这个worker组的数据更新

```
ConcurrentHashMap<String, Set<String>> workerGroupNodes = new ConcurrentHashMap<>();
```

唯一不同的是，update还需要更新

```
workerNodeInfo里面的数据
```

删除还需要发送告警信息，将告警信息插入数据库t_ds_alert

## 三、执行WorkflowExecuteThread

### 三一、startProcess

三一二、构建有向无环图

1、查出processDefinition，taskRelation，taskDefinition

2、把taskRelation，taskDefinition转换成TaskNode，就是已posttask为核心做的一个list

3、如果是forbidden的Task，添加到forbiddenTaskList里面去

4、封装new ProcessDag，taskNode是node，taskRelation是边

5、封装DAG

三一三、submitPostNode

1 获取开始节点

2 创建taskInstance，初始状态为提交成功

3 把task放入readyToSubmitTaskQueue

4、submitStandByTask

4、1 根据不同的task选择不同的TaskProcessor去处理，一般是common

4、2 TaskProcessor初始化

4、3 CommonTaskProcessor submittask，调用 processService.submitTask()

4、3、1 先把taskInstance插入db t_ds_task_instance

4、3、2 假如是添加过的，就执行createSubWorkProcess

4、3、3 dispatchTask，把taskInstance分装成taskPriority，再put进taskUpdateQueue中

4、 5 removeTaskFromStandbyList

5、updateProcessInstanceState ，有变化就update，没有就不用

## 四、TaskPriorityQueueConsumer

1、不断循环从taskUpdateQueue里面取数据

2、每次循环取3个task

3、dispatch task（同步的）

3、1 构建ExecutionContext，里面会构建TASK_EXECUTE_REQUEST的Command

3、2 分发出去，找到一个workerhost，向这个workerhost发送数据

有3种分发策略：1、随机，2、轮询，3、按照worker的负载去轮询分发（默认）

worker的负载去轮询分发，每1秒拉取一次worker的负载信息。在执行分发的时候会选出负载最轻的worker进行分发，但是再下一秒前，他会按照负载从大到小的顺序去轮询分发任务

3、分发成功则流程结束，分发失败，则再次添加入taskUpdateQueue

### 四一、NettyExecutorManager发送指令给worker

1、在初始化的时候启动一个客户端，但是不连接

2、要发送的时候去连接创建通道，懒加载，发送 TASK_EXECUTE_REQUEST Command

## 五、收到worker的ACK

1、发布taskResponseEvent（添加taskResponseEvent到eventQueue）

2、创建一个TaskResponsePersistThread然后put进processTaskResponseMap

3、然后往TaskResponsePersistThread add taskResponseEvent

4、TaskResponseEventHandler会去遍历processTaskResponseMap去拿TaskResponsePersistThread

5、判断TaskResponsePersistThread里面有没有event，把taskResponsePersistThread放进taskResponseEventHandlerMap

6、提交taskResponsePersistThread

### 五一、TaskResponsePersistThread

1、如果是ACK事件，先去改变数据库中taskInstance的状态，一般是running

2、发送DB_TASK_ACK给worker

3、如果是RESULT事件，先去改变数据库中taskInstance的状态，为result的结果

4、发送DB_TASK_RESPONSE给worker

## 六、收到Worker的RESULT

1、更新t_ds_task_instance

2、做一个TASK_STATE_CHANGE事件，给WorkflowExecuteThread

## 七、WorkflowExecuteThread处理事件TASK_STATE_CHANGE

1、处理TASK_STATE_CHANGE，判断task是否完成，调用taskFinished方法

2、调用submitPostNode(Long.toString(task.getTaskCode()))提交这个节点往下的下一个任务

3、如果有下一个任务，就继续提交，如果没有，进入下面的updateProcessInstanceState

4、最后updateProcessInstanceState，判断t_ds_process_instance是否要更新，如果当前的t_ds_process_instance是running，判断是否要更新为sucess