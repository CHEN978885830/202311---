### 1、java8的新特性，新的时间api

（1）Optional类的使用
（2）lambda表达式
（3）Stream api
（4）新的时间api

### 2、java的版本更新

以后每6个月就发一次更新，每3年发布一个持续稳定的版本

## 一、java9的新特性

### 3、JDK和JRE的关系

JDK是java Development Kit （java开发工具包）
JRE是java运行时环境

## 大的更新

### 4、java9的模块化

为什么要有模块化，没有模块化有什么缺点？
1、每次jvm启动的时候都会加载rt.jar，不管其中的类是否被classLoader加载，第一步整个jar都会被jvm加载到内存中去。占用内存比较大
2、代码量越来越大，有的类是对外暴露的，有的类不是，模块化很好的解决了，自己模块对外暴露哪些模块，哪些模块不暴露的问题。这样可以减少一个项目的复杂性
3、如果有module-info那么他就会把里面包切分成模块，你可以指定哪些模块暴露，哪些模块不暴露
4、maven引用以后，也必须要request了才可以使用

### 5、jShell命令
交互式的编程环境

### 6、多版本兼容jar包
可以弄一个jar包，既有java8，又有java9的代码，在不同环境中执行不同的代码
给一个默认的-C版本去打包，-release指定版本 再-C，可以打包多个文件夹

### 7、在接口中支持私有方法
可以在default方法中去调用
## 语法层面
### 8、钻石操作符，也可以写匿名子类了
java8这样写会报错

### 9、异常处理的try结构升级
可以在括号外面定义，让后把变量放在括号里面，此时这个变量就是final的了

### 10、下划线以后不能单独做变量名了

### 11、String的底层结构变更，Stringbuffer和StringBuilder也是一样
原先用的是char，现在用的是byte，因为堆空间中大多都是string，后面发现string里面大部分都是拉丁字符，所以用byte来存更加能够节省空间，同时增加一个encoding flag

### 12、集合用of api可以做不可变集合

## 二、java10的新特性

### 1、局部变量类型推断

（1）没有初始化的局部变量不能声明

（2）方法的返回值类型

（3）方法的参数类型

（4）构造器的参数类型

（5）属性

（6）catch快

### 2、copyOf 

List.of可以创建一个集合

List.copyOf可以得到一个只读的集合，如果里面的集合本身是只读的，如果参数不是一个只读集合，就会创一个集合这个集合是只读的

## 三、java11的新特性

### 1、string的新增方法

（1）isBlank()，包括空格换行都是在这里的

（2）stripTrailing() ，去除尾部空格

（3）stripLeading()，去除头部空格

（4）repeat(3)，复制字符串3遍

（5）"".lines().count()，判断行数有多少行

### 2、optional的方法

isEmpty()是否value为空

ifPresentOrElse(consumer 方法，runable 方法（空参方法） )value非空，执行1，value为空执行参数2的函数

or(supplier)，如果非空返回对应的optional，如果为空就返回

stream() value非空，返回一个包含该value的stream，为空则返回一个空的stream

orElseThrow() value非空，返回value，否则抛异常

### 3、局部变量类型推断的升级

就是在使用lambda表达式的时候加上var再加上注解

### 4、全新的Http客户端api

httpClient替换httpUrlConnection

对http2和websocket的支持，http2，可以一个连接同时发送多个请求，多路复用，并且支持服务器推数据。

### 5、更简化的编译运行程序

可以直接运行java Helloworld.java文件，不需要编译成.class文件

1、如果有好几个类，只会执行第一个类

2、必须要有main方法

3、允许文件里面有多个类，但是不允许调用其他文件中的类

### 6、废除Nashorn引擎

### 7、ZGC
ZGC是一个并发，基于region，压缩型的垃圾收集器，只有root扫描阶段会stop the world，因此停顿时间不会随着堆增长和存活对象的增长而变长

目标：支持TB级内存容量，暂停时间低(<10ms)，对整个程序吞吐量影响小于15%，将来还可以扩展实现机制，以支持其他功能，例如多层堆或压缩堆

优势：
1、gc暂停时间不会超过10ms
2、既能处理几百M的小堆，也可以处理几个T的大堆
3、和G1相比，应用吞吐能力不会下降超过15%
4、为未来的GC功能和利用colord指针以及Load barrier优化奠定基础
5、初始只支持64位系统