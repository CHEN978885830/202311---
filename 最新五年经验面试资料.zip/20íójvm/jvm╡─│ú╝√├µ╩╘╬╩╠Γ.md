## 一、如何去分析内存溢出

1、添加这个参数-XX:+HeapDumpOutOfMemoryError，在内存溢出的时候去dump出堆

2、添加-XX:HeapDumpPath=/tmp/xxx.hprof 可以更改堆内存存放的目录

3、用jvisiual去看，或者用Memory Analysis去看

## 二、如何排查内存泄漏

1、jmap -histo pid 查看内存中的实例数量以及内存大小

jmap -histo pid | top 30

jmap -heap pid  查看堆内存使用情况

jmap -dump:live,format=b,file=heap.bin 生成内存快照信息

2、jinfo -flags pid 查看所有的jvm配置情况

如果看到某个对象特别多，那么可能这个对象就没有被释放掉，我们得找到这个对象看看是否是某个地方被gcRoot引用了

3、jstat -gcutil 1 2000 10

jstat -gc  1 2000 10

可以分代回收的内存变化情况，也可以看到元数据区的情况

4、jstack 

打印栈的情况，分析线程死锁的情况

## 三、G1垃圾回收器的特点是什么？

G1也就是垃圾优先收集器

1、他会把空间划分为不同的region，默认是2048块region，region可能是E，可能是S，可能是O，不连续，可以相互转换

2、每个region都有一个回收价值，高回收价值的先被回收

3、可以设置一个预期停顿时间，g1会尽可能的去满足这个停顿时间

4、新生代会一开始占用百分之5，后面可以动态的扩容，不用我们去写死

5、大对象放入humongous

6、（1）当年龄达到阈值会放入老年代，（2）survivor区的某个年龄段存放的对象比例已经超过百分之50了，那么例如年龄为0~5的对象占用了百分之50，那么就把6晋升到老年代

## 四、双亲委派机制

1、避免类的重复加载

2、保护java核心类不会被随意替换