## 1、concurrentHashMap的结构
数据+链表+红黑树，里面有个Node，存key，value，和hash值，还有next（作用是发生hash冲突的时候，生成一个链表用的）
## 2、concurrentHashMap的负载因子可以修改吗
普通的hashMap的负载因子是可以修改的，concurrentHashMap的负载因子可以修改是0.75，代表hash表中已存元素的数量和总容量的比值，超过就会扩容
## 3、concurrentHashMap是如何保证线程安全的

cas+synchronize

当没有数据的时候，就用cas来放置数据，当有hash冲突的时候，就用synchronize对节点node加锁来保证

## 4、spread散列算法
（1）避免出现hash冲突，用高16位异或上低16位的数据，让hash值充分考虑高位的hash值情况，而int是32位的，从而避免hash冲突
（2）然后把key的hash值改为正数，key为负数有特殊含义
-1：hash for forwarding nodes，当前数值正在迁移
-2：hash for root of trees 下面放的是一颗树
-3：hash for trransient reservations 当前位置已经被预定了

## 5、initTable()

为什么要再做一次判断？单例模式DCL，懒汉模式。

在初始化的时候是如何保证线程安全的？用的是sizeCtl关键字，通过cas自旋的操作，来初始化Node数组

## 6、sizeCtl：
-1：代表当前map数组正在初始化，此时会调用Thread.yield
小于-1：代表正在扩容
0：代表还没有初始化
正数：如果没有初始化，代表要初始化的长度。如果已经初始化了，代表扩容的阈值
解释：如果没有给初始的capacity，sizeCtl默认是0，如果给了默认是有值的代表初始化的长度，在初始化的时候，会设置成-1，初始化结束以后，又把他设置成扩容的阈值，

如果sizeCtl为0，初始化的大小默认为16

## 7、hash值的概念

一个是使用key的hashCode得到的hash值，还有一个是Node他自己持有的hash值

如果是正数：说明是链表，或者为空
-1：hash for forwarding nodes，当前数值正在迁移
-2：hash for root of trees 下面放的是一颗树
-3：hash for transient reservations 当前位置已经被预定了

## 8、什么时候转红黑树

链表长度大于8，并且数组长度大于64，如果只是链表长度大于8

## 9、扩容

得到一个扩容戳，长度32位，高16位为扩容标识，低16位为扩容线程数

sizeCtrl小于-1：如果是-2表示有1个线程正在扩容，如果是-3表示有2个线程正在扩容。

## 10、transfer

stride：这个值代表了每个线程的最大迁移数量（最小是16）