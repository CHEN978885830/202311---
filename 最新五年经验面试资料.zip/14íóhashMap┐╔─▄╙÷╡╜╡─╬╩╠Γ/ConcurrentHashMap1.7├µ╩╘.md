## 一、segment数组的大小是如何确定的

初始化的时候有一个concurrencyLevel有一个初始化的并发等级，我们的数组大小需要大于这个并发等级，并且是2的倍数，这样做是为了（h & segments.length-1）是ok的

segmentMask = ssize - 1

## 二、内部数组的初始化大小是怎么确定的

首先cap要是2的倍数，且要大于 c = initialCapacity /ssize，里面还有一个扩容因子，算出一个扩容阈值，内部实际存数据的是HashEntry

## 三、为什么要提前创建一个segment对象

虽然下次查找到的下标值的value可能为空，我们可以复用之前segment对象里面的一些初始值，扩容阈值等等信息

## 四、segment数组的segment是如何保证线程安全的

用了多次判断+unsafe方法的cas操作，来在put的时候获取segment对象