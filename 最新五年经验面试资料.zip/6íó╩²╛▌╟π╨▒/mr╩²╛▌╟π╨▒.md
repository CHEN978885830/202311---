1、在第一次map阶段在大key上加上随机数，分配到多个reduce里面去聚合，再做一次mapreduce，两段式提交

2、增加reducer，增加并行度

3、根据数据分布情况，自定义散列函数，将key均匀分配到不同的reducer

