## 一、count(distinct)

select count(distinct a) from table 改为

```sql
select count(cnt) from (
	select key from table group by key
)
```

## 二、join

小表与大表join，用mapjoin

## 三、count(distinct ) 空值过多

可以先过滤掉空值再加1

## 四、不同数据类型关联产生的数据倾斜

如果一个int和一个string进行join，那么会将string类型的数据都放到一个reduce里面去

## 五、参数调优

### 1、hive.map.aggr=true，开启map端combiner

即select user.gender,count(1) from user group by user.gende，他会先在map端进行聚合。

hive.groupby.mapaggr.checkinterval = 100000 (默认)
hive.map.aggr.hash.min.reduction=0.5(默认)

checkinterval是取十万个样本，做map预聚合，如果得到的聚合结果/十万 < 0.5，那么就不开启。

### 2、hive.groupby.skewindata=true

开启数据倾斜时负载均衡，这个会自动生成2个map，第一个map先加随机数，map再reduce，第二个map再去掉随机数，做二次聚合达到效果

set hive.skewjoin.key=100000;
判断数据倾斜的阈值，如果在join中发现同样的key超过该值，则认为是该key是倾斜key。

set hive.optimize.skewjoin.compiletime=true;
指定是否开启数据倾斜的join编译时优化，默认不开启即false，即对倾斜的key做单独处理

### 3、小表在左边做驱动表

驱动表

### 4、用case when把null改为随机数

用case when 把null改为随机数，而不是用where 

### 5、map端设置压缩

### 6、增加reduce的个数

