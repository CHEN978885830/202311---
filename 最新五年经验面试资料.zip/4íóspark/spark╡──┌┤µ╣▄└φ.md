## 一、怎么看内存用的好不好

1、如果我们发现我们的缓存有Size on disk 说明留给缓存的内存少了

2、当我们发现有shuffle spill (memory) 甚至 shuffle spill (disk)

## 二、内存分为几个部分

1、大的是Executor Memory 分为 JVM Memory 和 Reserved Memory（大约是300MB） 两个部分

2、JVM Memory 分为  User Memory  和  Memory 两个部分 

而User Memory = 1- spark.memory.fraction = 0.4 

3、unified Memory  = spark.memory.fraction = 0.6 而这块内存又分为 Execution Memory 和 Storage Memory ，分别为0.3  和 0.3，这个由spark.memory.storageFraction决定 默认是 0.5

4、Execution Memory是用来存放一些shuffle之类的东西，storageMemory是用来存一些rdd缓存

5、User Memory 用来存用户自定义的数据结构，spark的元数据，用户创建的UDF，RDD的依赖信息

## 三、unified Memory

同一内存管理，当execution 和 storage ，当某个需要的内存比较多的时候，可以占用对方的内存。

## 四、怎么配置

先运行一下task，观察一下storage用了多少，Execution用了多少