## 一、如何理解RDD

1、分布式计算引擎，会把很大的数据进行大散，分散到多台机器上进行并行计算，为了避免开发人员去过多的关注数据细节，于是就给这些分散在多台机器之上用的数据抽象成一个数据集RDD对象。让我们操作数据像操作本地集合一样

叫弹性分布式数据集。

弹性体现在他的容错性：每个RDD都有dependencies属性，记录了父RDD的元数据信息，RDD间的依赖关系构成了一个血统，父RDD通过算子得到子RDD。当RDD存在异常时，可以根据血统关系来恢复

体现在其分片可以调整，我们可以设置他的并行度，切分成多少个task

## 二、spark任务的执行流程

1、客户端向master发送注册和申请资源的请求，其中master主要负责任务资源的分配

2、master收到申请资源的请求后，会向指定的worker节点发送请求，woker节点会开启对应的executor进程

3、executor进程会向driver端注册，申请要计算的task

4、driver会划分DAG，DAGscheduler划分DAG，最终会把task提交到executor进程里面去运行

4.1 driver端会运行main方法，他会创建一个sparkContext上下文对象，该对象是所有spark程序执行的入口，在构建sparkContext上下文的内部，

4、2 它也会构建两个对象DAGScheduler和taskScheduler

4、3 在action这里会触发任务的真正执行，会根据RDD的依赖关系生成DAG有向无环图，发给DAGScheduler对象

4、4  DAGScheduler对象会按照宽依赖，进行stage的划分

4、5 每个stage内部有多个可以并行运行的task线程，将这些并行运行的task线程放在一个taskSet集合中，把taskSet集合发送给taskScheduler对象

4、6 TaskScheduler对象会按照多个stage的依赖关系，前面的stage的task先运行，后面的再运行，然后他会将每个task发送给executor

5、当所有任务执行完成后，driver端会向master发送一个注销请求，master收到请求后，通知对应的worker节点关闭executor进程，释放资源

