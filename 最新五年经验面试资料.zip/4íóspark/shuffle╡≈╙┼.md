## 一、spark.shuffle.file.buffer 默认值：32k

这个参数调大，可以减少磁盘io的次数

## 二、spark.reducer.maxSizeInFilght 默认值：48m

下游每次拉取多少数据

## 三、spark.shuffle.io.maxRetries 默认值3

拉取数据失败重试次数

## 四、spark.shuffle.io.retryWait 默认值 5s

每次重试的间隔

## 五、spark.shuffle.sort.bypassMergeThreshold 默认值：200

当task数量小于200的时候，不会进行排序操作，而是采用sortShuffleManager的方式去写数据

## 六、spark的shuffle调优

1、spark在1.2以前，用的是hash shuffle是上游的task会到下游的多少个task里面去就会生成多少个文件，这样会产生大量的磁盘io，不好

file = M个上游task * N个下游task

2、spark在1.2以前，hash shuffle 优化是上游在写入磁盘前，会进行排序，然后合并，会生成并行度 * 下游task数量个磁盘文件。

file = M个分区 * N个executor 的数量

3、SortShuffleManager

第一个stage有n个task，就有N个文件，除了正常的磁盘文件之外，还有一个索引文件，告诉磁盘文件里面的哪段是输入下游的哪个task，task内部根据数据所属的partition id进行排序，再根据key进行排序，最终生成一个有序的文件，和一个索引文件，索引文件可以去顺序读取这个文件中的数据，从哪里到哪里是属于某个分区的某个task

4、bypass的sortShuffleManager

不用排序，首先：

task数量<spark.shuffle.sort.bypassMergeThreshold参数，还有就是不是聚合类算子（比如reducebyKey）。其实这个就是将数据标记上是某个partitionid以后，直接生成一个临时文件，最终再将这个文件进行合并，再生成索引文件，这个减少了排序的过程，类似于退化成了hashshuffle，当下游的task数量表比较少的时候是可以的。

## 七、shuffle的两个阶段

先shuffle write，再shuffle read

## 八、为什么要排序

sort 是先按照partition id 排序，每个partition再按照内部的key排序，这样索引文件就好取了

