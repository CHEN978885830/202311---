## 一、分布式快照算法

Chandy-Lamport算法的变体，异步分界线快照算法。

1、触发checkpoint的时候相当于jobmanager给taskmanager发送一个指令，然后taskmanager从source插入一个barrier的数据

2、每个operator收到barrier就保存一下状态，所有状态保存完了，就算是成功

3、当上游有多个source，当前task需要收到所有的source的barrier的时候才会去保存

4、当下游对应多个task，barrier会被广播出去

5、当前task的barrier没有完全接收完毕之前，收到了一个上游的barrier，他的后续数据需要先缓存起来，不能让他改变当前state

6、等当前task checkPoint过后，再去处理缓存数据，再处理接下来的数据

缺点：

当背压的时候，就会缓存大量的数据

11以后启用了不对称的检查点，当收到一个barrier的时候，就启动检查点，我们把缓存的数据也放入checkpoint中，这样我们的checkpoint需要保存更多的信息

## 二、如何从故障中恢复

要求使用checkpoint，并且上游的source有偏移量，我们要在state中保存其偏移量，恢复source的时候就可以恢复state，再根据state的偏移量去拿数据。所以checkpoint会保证at-least one

## 三、检查点的配置

1、设置检查点的间隔时间

2、设置存储位置，默认是jobmanager的内存，可以是文件系统

3、设置检查点的超时时间

4、设置状态一致性级别

5、两个checkPoint之间的最小间隔

6、maxConcurrentCheckpoints，检查点的最大并发数量，同时有多少个在工作

7、enableUnalignedCheckpoints开启非对其的操作，状态一致性必须是Exactly once

8、enableExternalizedCheckpoints在作业取消的时候是否还保留检查点，选择保留吧

9、tolerableCheckpointFailureNumber容忍检查点失败

## 四、保存点

1、做版本管理和归档存储

2、更新flink版本

3、更新应用程序，只要他不涉及到状态的变化

4、调整并行度

只要状态和拓扑结构是不变的，那么保存点就是可以用的，但是我们需要给每个算子设置一个uid，只要uid不变整个状态的数据类型和拓扑结构没有变化，就可以。

其内部是由算子id+key value结构保存的

## 五、使用保存点

正在运行的作业，加一个保存点

```
bin/flink savepoint :jobid  [:targetDir] 后面可选，可以在yaml里面配置
```

停止当前作业并且加上保存点

```
bin/flink stop --savepointPath [:targetDir] :jobId
```

从保存点重启应用

```
bin/flink  run  -s :savepointPath  [:runArgs]
```



