## 一、什么是一致性

不该丢失，也不应该重复计算

## 二、分类

at-most-once：出现故障，直接恢复

at-least-once：至少数据不丢失，数据源只要可以重放数据，就可以实现

exactly-once：精确一次性

## 三、exactly-once

内部保证--checkpoint

source端--可重设数据读取位置

sink端--故障，数据不会重复写入

幂等写入：故障恢复的时候，会有短暂的数据不一致

事务写入：预写日志，两段式提交

### source：

kafka会记录消费者消费的offset值，下次还从这个地方开始消费

### 内部：

1、开启checkpoint：在checkpoint完成后提交

setComitOffsetsOnCheckpoints(true)

2、开启checkpoint：禁用checkpoint提交，不提交消费者组offset

setComitOffsetsOnCheckpoints(false)

3、不开启checkpoint：依赖kafka  client自动提交

定时提交

### sink：

1、幂等性写入：本身redis或者hbase就是一个keyValue的数据库，只要key一致，数据是不会重复插入的。只是在数据恢复的时候有短暂的不一致。

mysql也是按照id，来插入或者更新

2、事务：

（1）预写日志：

在检查点完成的时候

使用GenericWriteAheadSink，重写其sendValue方法，对这批数据进行写入，如果写入成功则返回true，然后他才会提交checkpoint，如果写入失败，希望下次重试，则返回false

（2）两阶段提交

TwoPhaseCommitSinkFunction，flink kafka producer则实现了这个抽象类。当我们的checkpoint完成了，就真正提交事务给外部系统，如果前面的数据处理完成了，后面的数据发生了故障，那么就会回滚到前面的checkpoint，撤回已经提交了的代码，kafka是支持事务的，消费者也可以实现read_commit只读到提交了的事务

所谓两段式提交，就是先预提交，等到checkpoint完成了才commit，中间如果出现错误或者checkpoint保存失败，都将回滚事务。

我们也可以利用mysql的事务特性来实现这个抽象类

数据湖也是有事务特性的，也可以回滚至某个状态