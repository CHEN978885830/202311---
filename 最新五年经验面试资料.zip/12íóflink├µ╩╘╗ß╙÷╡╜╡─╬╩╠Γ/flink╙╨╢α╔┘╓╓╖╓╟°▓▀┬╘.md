8种分区策略
1、global：Global分区策略重分区，每次只会打到下游的第一个分区
2、shuffle：采用SHUFFLE分区策略重分区，随机打到下游的分区里面去
3、forward：forwardPatitions，用于在同一个operatorChain中，上下游数据传递，要求上游并行度等于下游
4、rebalance：轮询的打到下游的task实例中
5、rescala partition：用rand Roubin 选择下游的一个task进行数据分区，如果上游有2个并发下游有6个并发，1个并发会找3个并发进行轮询
6、broadcast：会把上游的数据广播到下游的每个分区
7、keyhashPartition：会按照key的hash值取模输出到下游的实例中，同一个key会到同一个分区中
8、自定义分区：实现partitioner接口
