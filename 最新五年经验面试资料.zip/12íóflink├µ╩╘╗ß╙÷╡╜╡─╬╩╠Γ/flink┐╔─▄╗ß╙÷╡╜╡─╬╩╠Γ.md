## 一、Flink和SparkStreaming有什么区别

1、flink是实时处理引擎，基于事件驱动。而spark Streaming是微批（Micro-Batch）的模型

2、时间机制：Spark Streaming只支持处理时间。Flink支持处理时间，事件时间，注入时间。同时有watermark来处理滞后数据

3、容错机制：Spark Steaming 通过checkpoint 实现数据不丢失，但无法做到恰好一次处理语义。flink则使用两阶段提交协议和checkpoint实现精准一次性处理

## 二、flink的编程模型

1、source输入

2、Transformation 中间转换

3、sink数据输出

## 三、如何设置并行度

1、系统层面（flink客户端的配置yml文件中配置）

2、客户端层面（提交flink run -p的时候配置）

3、执行环境层面（getExecutionEnvironment.setParallelism(2)设置）

4、算子层面（setParallelism(3) 实际算子时设置）

优先级：算子>执行环境>客户端>系统

设置了并行度，他可以把算子拆分成2个子任务去执行

## 四、flink的slot和parallelism

slot指的单个taskmanager并发能力，parallelism指所有taskmanager的并发能力

## 五、Flink重启策略有哪些（一会研究一下）

固定延迟重启策略

故障率重启策略

没有重启策略

fallback重启策略

## 六、exactly once

1、保证数据不丢失，且只被处理一次

需要保证：

1、sink端支持事务，而支持事务的前提条件是具备 原子性（要么都成功要么都失败）、一致性（执行前后数量不变），隔离性（不同的事务并发操作同样的数据是互补干扰的）、持久性 （一旦被提交就会永久保存到数据库中）

2、sink端支持幂等性，通过写入时保证uppsert语义从而保证下游的写入幂等性，实现exactly once

clickhouse为什么不支持exactly once？

首先clickhouse是一个olap数据库，不擅长update和delete。所以不支持exactly once语义，但可以保证 at least once语义，这样数据会重复，但不会丢失

## 七、flink架构

1、JobMaster：负责把JobGraph转化成一个物理层面的数据流图，包含了所有可并发执行的任务，JobMaster会向ResourceManager发出请求，申请执行任务必要的资源，当获取足够的资源后就将数据流图发往taskManager

2、ResourceManager：负责资源的分配和管理，资源指TaskManager的任务槽（task slots），任务槽是集群集中资源调配单元，执行计算的一组cpu和内存资源

3、Dispatch用来提交应用，每个新提交的作业启动一个新的JobMaster组件，启动web Ui ，展示，监控作业执行的信息

4、TaskManager：启动后会向resouceManager注册他的slots

## 八、作业的提交流程

1、作业提交流程包括，local方式，standalone方式，yarn方式和k8s方式

yarn方式又分为：

（1）yarn per job模式：应用代码在客户端运行，向resourceManager申请资源，resourceManager创建jobmanager和taskManager，每个task独享一个taskManager和jobmanager，能很好的做好资源隔离

（2）yarn application模式：和per-job的区别是main函数是在集群中执行的

（3）yarn session模式：先启动集群，再提交任务，所有任务都是在一个集群中运行的，优点是节约资源

## 九、名词解释

1、Dataflow：flink程序在执行的时候会被映射成一个数据模型

2、Operator：Operator分为：source/transform/sink

3、partition：数据流模型并行执行，会形成1~n个分区

4、Subtask：每一个子任务就是一个subTask

5、parallelism：并行度，就是可以同时运行的子任务数

6、Operator chain：两个one to one的operator可以合并成一个operator chain

8、task：operator chain或者无法单独合并的单个operator叫task

9、task slot：一个slot里面可以跑多个subtask

## 十、两个Operator之间传递的时候

1、有One to One：两个map之间数据传递

2、有Redistribuing：把数据重新发配到不同的分区里面去，重分区

## 十一、流程图的生成

StreamGraph：最初的执行流程图，也就是算子与算子之间的顺序

JobGraph：将OneToOne的Operator合并成OperatorChain

ExecutionGraph：将JobGraph根据代码中**设置的并行度**和**请求资源**进行并行化规划--在jobManager上生成，

物理执行图：将ExecutionGraph的并行计划，落实到具体的TaskManager上，**将具体的SubTask落实到具体的TaskSlot内进行运行**

## 十二、flink的分区策略

GlobalPartitioner：将所有的数据都发送到下游的某个算子

ShufflePartitioner：随机选择一个下游的算子实例发送

BroadcastPartitioner：发送到下游的所有算子实例

RebalancePartitioner：轮询的方式发送给下游的算子实例

RescalePartitioner：上游并行度是2，下游是4，上游的1个task只会发送给下游其中的两个task

BroadcastPartitioner：把数据发送给下游所有的算子实例

ForwardPartitioner：发送到下游的第一个task，保证上下游算子并行度一致

KeyGroupStreamPartitioner：根据key的分组索引选择发送到下游的subtask

CustomPartitionerWrapper：

## 十三、窗口函数有哪些

按照驱动类型来分：

1、时间窗口

2、计数窗口

按照窗口分配数据的规则来分类：

1、滚动窗口

2、滑动窗口

3、会话窗口

## 十四、窗口api有哪些

窗口api有带keyBy和不带keyBy的两种：

如果没有了keyBy所有的数据都会到一个task里面去执行，相当于并行度变成了1。

相同key的数据会划分到相同的数据流

TumblingProcessingTimeWindows.of(Time.seconds(10)) 滚动窗口

SlidingProcessingTimeWindows.of(Time.seconds(10),Time.seconds(6)) 滚动窗口

ProcessingTimeSessionWindows.windowGap(Time.seconds(5)) 会话窗口，超时间隔是5秒

## 十五、怎么理解waterMark

waterMark是一个事件语义下的逻辑时钟，当waterMark进展到0到10秒的时候，窗口应该被触发关闭了。通过waterMark我们可以接收延迟的数据

## 十六、算子链

一些算子之间上下游不需要重分区，会合并成一个大的task，每个task被一个线程执行，这样的技术成为算子链

## 十七、执行流程

客户端生成逻辑流图，作业流图（不分区的算子合并成一个大的任务，算子链），发送给jobMaster，jobMaster会把逻辑流图转化为执行流图（并行度），然后向ResourceManager申请资源，ResourceManager向taskManager申请slot，然后JobMaster把任务拆分成task提交给各个slot去运行，每个taskManager定期上报任务状态