## 一、端到端数据一致性

1、内部保证 checkPoint

2、source端 可重设数据的读取位置

3、sink端   从故障恢复时，数据不会重复写入外部系统

幂等性写入：多次写入效果一样

事务写入：构建事务对应的checkpoint，等到checkpoint真正完成的时候，才把所有的结果写入sink系统中

## 二、预写日志

1、把结果数据先当成状态保存，然后在收到checkpoint完成的通知时，一次性写入sink系统

2、简单易于实现，由于数据提前在状态后端做了缓存，所以无论什么sink系统，都可以用这种方式一批搞定

3、DataStream  API提供了一个模板类，GenericWriteAheadSink，来实现这种事务性sink

4、在一次性写入的时候写入失败了，还是不行，还是得让数据库支持事务。

5、还有就是在提交以后还得发一个确认消息给jobmanager，如果这个过程失败了，也会重复写入

## 三、两阶段提交（Two-Phase-Commit，2PC）

1、对于每个checkpoint，sink任务会启动一个事务，并将接下来所有接收的数据添加到事务里

2、然后将这些数据写入外部sink系统，但不提交它们--这时只是“预提交”

3、当它收到checkpoint完成的通知时，它才是正式提交事务，实现结果的真正写入

4、这种方式真正实现了exactly-once，它需要一个事务支持外部sink系统。Flink提供了TwoPhaseCommitSinkFunction接口

要求：

1、sink需要提供事务支持

2、在checkpoint的时间间隔内，必须能够开启一个事务并接收数据写入

3、在收到checkpoint完成的通知之前，事务必须是“等待提交”的状态。在故障恢复的情况下，这可能需要一些时间。如果这个时候sink系统关闭事务（例如超时了），那么未提交的数据会丢失。

4、sink任务必须能够再进程失败后恢复事务

5、提交事务必须是幂等性操作

## 四、flink加kafka实现两阶段提交

1、flink内部

Flink内部有checkpoint机制，可以保存offset的值

2、输入端kafka

kafka可以持久化，而且根据offset重新读取

3、输出端

FlinkKafkaProducer，它实现了TwoPhaseCommitSinkFunction接口：

## 五、整个流程

1、checkPoint开始给taskManager会插入一个barrier，标志这进入预提交阶段

2、source任务保存偏移量，到状态后端，通知jobmanager继续向下传递

3、其他task收到barrier，保存状态

4、DataSource将状态保存，同时预提交结果

5、当checkPoint保存成功了，再真正提交事务

## 六、需要的配置

1、启用checkPoint

2、在FlinkKafkaProducerde的构造函数中传入Semantic.Exactly_ONCE

3、配置kafka读取数据的消费者隔离级别，默认的kafka的隔离级别isolation.level 是read_uncommitted，也就是可以读取未提交的数据。这样一来，外部应用就可以直接消费未提交的数据，对于事务性的保证就失效了。所以隔离级别配置为read_committed

4、事务的超时配置

Flink的Kafka连接器中配置的事务默认超时时间transaction.timeout.ms默认是1小时，而Kafka集群配置的事务最大超时时间transaction.max.timeout.ms默认是15分钟。所以在检查点保存时间很长时，有可能Kafka已经认为事务超时了，丢弃了预提交的数据。所以flink事务超时时间应该小于kafka的时间。

