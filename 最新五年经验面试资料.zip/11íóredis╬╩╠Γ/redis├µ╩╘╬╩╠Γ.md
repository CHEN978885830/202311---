## 一、redis为什么快？

1、单线程实现：redis单线程处理请求，避免了多个线程间的切换和锁资源的争用开销

2、IO多路复用模型：redis采用IO多路复用技术，使用单线程来轮询描述符，将数据库的操作都转化成了事件，不在网络IO上花费过多的时间

3、基于内存：Redis是内存存储，没有磁盘IO上的开销，读写速度快

4、高效的数据结构：Redis每种数据结构底层都做了优化，目的就是为了更快的速度。

## 二、redis的底层数据结构

1、简单动态字符串 SDS

2、双向链表

3、压缩列表

4、哈希表

5、跳表

6、整数数组

string：用到简单动态字符串

list：双向链表，压缩表

hash：压缩列表，哈希表

sorted Set：压缩列表，跳表，字典

set：哈希表，整数数组

## 三、渐进式hashtable形式

 整体是一个渐进式hashtable的格式来存储数据

## 四、简单动态字符串

### 1、整体结构

头部，数据，\0，有了这个可以用string.h里面的函数

### 2、具体数据结构

头部结构：

1 byte

```c
sds.h

## never used
struct __attribute__((__packed__)) sdshdr5{
   unsigned char flags;
   char buff[];
}

struct __attribute__((__packed__)) sdshdr8 {
   uint8_t len; // 用了多少  
   uint8_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr16 {
   uint16_t len; // 用了多少  
   uint16_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr32 {
   uint32_t len; // 用了多少  
   uint32_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr64 {
   uint64_t len; // 用了多少  
   uint64_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 可变字符串存数据
}
```

### 3、为什么不直接用字符串

1、常数复杂度获取字符串长度

2、二进制安全：C语言里面是用\0去判断字符串是否结束，我们外部的数据是很复杂的，他不能直接通过\0去判断是否结束

3、防止缓冲区溢出：我们在做字符串拼接的时候，会去检查长度，防止缓冲区溢出的情况，如果满足不了，就进行扩容

4、减少修改字符串的内存重新分配次数

5、兼容部分C字符串函数：为什么最后面要\0，就是为了可以兼容部分函数

## 五、如何存储整形

1、如果他是整形，那么就直接不开空间直接用指针本身去存储

## 六、embstr和raw类型

用object encoding str去看，小于44是embstr，大于44是raw类型

因为：CPU缓存行，缓存行一次是拿64个字节，因为redisObject：本身占用16个字节（占用type 4bit，encoding 4bit，lru 3个字节，refcount 4个字节，ptr 8个字节），sdshdr8本身元数据占用4个字节包括（len 1个字节的uint8，alloc 1个字节，flag 1个字节，char 的\0占用1个字节

## 七、redisObject

```
typedef struct redisObject{
    unsigned type:4;//bit
    unsigned encoding:4;//4bit
    unsigned lru:LRU_BITS;//3byte
    int refcount;//引用计数器4byte
    void *ptr;//8byte
}
```

## 八、redis如果弹出一个元素，未处理完就丢失了

可以用BRPOPLPUSH，先弹出来，然后再push到另一个地方去，这样怎么也不会丢失了

## 九、list的数据结构

ziplist+双向链表（quickList）

1、quickList要保存next指针和value指针，一个数据就是16个字节

2、而且每次添加元素都得重新开辟一块内存空间相当麻烦

ziplist是一块连续的空间，他不会需要用指针去解析

6.0开始用listpack结构替换了ziplist

ziplist的数据结构：

zlbytes  zltail  zllen   entry...entry zlend

zlbytes：4个字节存整个ziplist占的总字节数

zltail：4个字节存整个zltail占的总字节数

zllen：2个字节  也就是元素个数，所以一个ziplist最多存储2的16次方-1个元素

zlend：始终是255用来标识整个链表结束

entry：分为prevlen，len，data

prevlen：靠prevlen确定往前多少个字节就能拿到一个entry首地址。采用变长编码，如果前一个entry长度<254字节，用一个1字节就可以存下，如果>255，当前entry需要5个字节，这5个字节里面第一个字节存254，剩余4个字节存长度。

len：也是变长编码。

data：

zipList：每次如果空间不够，就要去扩容很麻烦，所以我们加上双端链表来解决这个问题

## 十、Set

1、set用的是一种有序的数据结构去做的，用的是value为null的一个字典

2、如果全是int，那么就是intset（是有序的，其实就是一个结构体里面有个数组）

3、如果有非整形，或者数据量特别多，就是hashtable

set-max-intset-entries 512这个我们可以配置

## 十一、Hash数据类型

底层是一个字典（dict），用k-v来存储，当数据量比较小的时候用ziplist来存储，他是一个元素key-value拆成两个元素存在ziplist里面的

hash-max-ziplist-entries  512 （元素个数超过512用hashtable编码）

hash-max-ziplist-value  64  （单个元素大小超过64byte用hashtable编码）

## 十二、ZSet

底层是字典+跳表，当元素比较少的时候用ziplist编码，

## 十三、redis的内存淘汰策略

可以同时配置多种

1、noeviction：不使用内存淘汰策略：当内存空间超过maxmemory时，再有请求过来就返回错误

2、volatile-ttl：在设置了过期时间的key中，根据key的剩余存活时间先淘汰存货时间短的key。

3、volatile-lru：在设置了过期时间的key中选择最近最少使用的key进行淘汰

4、volatile-random：在设置了过期时间的key中随机选择key进行淘汰

5、allkeys-lru：在所有的key中选择最近最少使用的key进行淘汰

6、allkeys-random：在所有的key中随机选择key进行淘汰

## 十四、redis的内存持久化有哪些方式

有两种：一种是冷备份，一种是热备份

冷备份是RDB：redis可以固定时长去生成冷备份文件

优点：

1、RDB恢复数据更快

2、RDB的redis性能很好，每隔一段时间才刷到磁盘里面

3、RDB的占用的内存更小一些

缺点：

热备份AOF：每写一条日志就刷一次，降低了redis的性能，恢复数据也慢数据大

## 十五、redis的集群模式

redis集群模式：

优势：他是为了解决数据可以分片的问题，他可以横向扩容，里面数据存储用hash slot算法。可以做到多主，多从，可以做到分片和副本机制

特点：用了slot的方式，不同的数据会根据key打到某一个slot上面去

通信：用了gossip协议，gossip协议的基本思想是，随机选择一些相邻的节点将自身的状态信息广播出去，同时也会从邻居节点接收状态信息来更新自己的状态，这样周期性的通信会在整个分布式系统中形成一个类似于热力学中粒子运动的过程，状态信息会通过节点之间的随机传播，最终达到全局一致。

Gossip 协议的特点包括：

1. 高效性：Gossip 协议无需中心化管理，节点之间完全平等，基于随机选择邻居节点的方式进行信息传递，可以快速地实现全局状态同步。
2. 去中心化：Gossip 协议不需要单独的中心节点来管理状态信息的分发和同步，每个节点都可以独立地进行状态更新和传播。
3. 容错性：Gossip 协议可以自动适应节点加入、离开或失效的情况，通过随机选择邻居节点的方式来维护系统的可靠性和一致性。
4. 可扩展性：Gossip 协议可以很容易地进行水平扩展，增加节点数量不会影响系统的整体性能和可用性。

## 十六、哨兵模式

哨兵模式，就是主从哨兵模式，当一主多从模式，有一个哨兵节点负责监控主节点的状态，如果发生故障则进行故障转移，让从节点升为主节点，其他节点重新作为从节点。

## 十七、AOF文件过大

当同时满足根据上次重写大小的2倍，并且文件大小大于64M的时候。

读取所有缓存的键值对数据，让所有键值对生成一条最新的命令，将其写入到新的AOF文件中，重写完后就把旧的aof文件替换掉。

Redis的aof重写操作，是有bgRewriteAOF后台子进程来完成的，子进程会复制一份主进程的所有内存数据，这样可以使得子进程在aof重写期间，Redis可以继续响应客户端的命令请求。

aof完成以后

1、aof写同时写到新老的文件中

2、对新的aof文件改名，替换掉原有的aof文件

3、继续处理客户端请求命令

## 十八、redis的穿透、雪崩、击穿

1、穿透解决方案：大量请求根本不存在的key

（1）对空值进行缓存

（2）设置白名单

（3）设置布隆过滤器

2、雪崩解决方案：大量key集体过期，导致大量请求打到数据库

（1）在一些需要同一时刻设置过期时间的key上，设置缓存时间的时候加一个随机数，让他们不要同时过期

（2）对服务做限流降级，预先直到数据库的最大并发量

3、缓存击穿：某个热点key过期

（1）实时监控热点key，实时调整热点key的过期时间

（2）预先设定热门词汇，把key的时长进行调整