## 一、redis为什么快？

1、单线程实现：redis单线程处理请求，避免了多个线程间的切换和锁资源的争用开销

2、IO多路复用模型：redis采用IO多路复用技术，使用单线程来轮询描述符，将数据库的操作都转化成了事件，不在网络IO上花费过多的时间

3、基于内存：Redis是内存存储，没有磁盘IO上的开销，读写速度快

4、高效的数据结构：Redis每种数据结构底层都做了优化，目的就是为了更快的速度。

## 二、redis的底层数据结构

1、简单动态字符串 SDS

2、双向链表

3、压缩列表

4、哈希表

5、跳表

6、整数数组

string：用到简单动态字符串

list：双向链表，压缩表

hash：压缩列表，哈希表

sorted Set：压缩列表，跳表，字典

set：哈希表，整数数组

## 三、redis的数据结构hashtable

1、他用的是hashTable加链表来存储

2、使用渐进式rehash方式来扩容，长度达到一定程度就扩容

（1）当访问某个hash槽的时候，数据会去扩容

（2）还有就是轮询扩容，每次也是扩容一定数量

3、底层的数据用的是一个dictEntry数据结构来存储

4、value用的是一个redisObject数据结构

## 四、简单动态字符串

### 1、整体结构

头部，数据，\0，有了这个可以用string.h里面的函数

### 2、具体数据结构

头部结构：

1 byte

```c
sds.h

## never used
struct __attribute__((__packed__)) sdshdr5{
   unsigned char flags;
   char buff[];
}

struct __attribute__((__packed__)) sdshdr8 {
   uint8_t len; // 用了多少  
   uint8_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr16 {
   uint16_t len; // 用了多少  
   uint16_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr32 {
   uint32_t len; // 用了多少  
   uint32_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 存数据
}

struct __attribute__((__packed__)) sdshdr64 {
   uint64_t len; // 用了多少  
   uint64_t alloc; // 用了多少还剩下多少空间
   unsigned char flags; //用低3位标识lsb type 
   char buff[];  // 可变字符串存数据
}
```

### 3、为什么不直接用字符串

1、常数复杂度获取字符串长度，复杂度是O1，而普通C语言字符串读取长度的复杂度是On

2、二进制安全：C语言里面是用\0去判断字符串是否结束，我们外部的数据是很复杂的，他不能直接通过\0去判断是否结束

3、防止缓冲区溢出：我们在做字符串拼接的时候，会去检查长度，防止缓冲区溢出的情况，如果满足不了，就进行扩容

4、减少修改字符串的内存重新分配次数，我们会预分配多一些内存给redis

5、兼容部分C字符串函数：为什么最后面要\0，就是为了可以兼容部分函数

### 4、key的数据结构

无论是什么类型的key，存进去都会变成简单动态字符串

## 五、如何存储整形

1、如果他是整形，那么就直接不开空间直接用指针本身去存储，指针不再存内存地址，而是直接存整形值

## 六、embstr和raw类型

用object encoding str去看，小于44是embstr，大于44是raw类型

因为：CPU缓存行，缓存行一次是拿64个字节，因为redisObject：本身占用16个字节（占用type 4bit，encoding 4bit，lru 3个字节，refcount 4个字节，ptr 8个字节），sdshdr8本身元数据占用4个字节包括（len 1个字节的uint8，alloc 1个字节，flag 1个字节，char 的\0占用1个字节）这样用去20个字节，那么如果str本身小于44个字节，他则将redisObject和str放在一起存储，就是embstr

## 七、redisObject

```
typedef struct redisObject{
    unsigned type:4;//bit
    unsigned encoding:4;//4bit
    unsigned lru:LRU_BITS;//3byte
    int refcount;//引用计数器4byte
    void *ptr;//8byte
}
```

## 八、redis如果弹出一个元素，未处理完就丢失了

可以用BRPOPLPUSH，先弹出来，然后再push到另一个地方去，这样怎么也不会丢失了

## 九、list的数据结构

list用的是quicklist数据结构：采用linkList+ziplist来存储，ziplist默认最大是8kb，中间的一些节点可以压缩，首尾不压缩

linkList：要记录头尾指针每个要占用8个字节

ziplist：是一块连续的内存空间，元素记录当前元素长度和上一个元素的长度，利用长度指向上下游元素，而长度信息一般使用4个字节就可以存储

linkedList的缺点：

1、linkedList要保存next指针和value指针，一个数据就是16个字节

2、而且每次添加元素都得重新开辟一块内存空间相当麻烦

ziplist的缺点：

1、扩容麻烦

2、增删大数据的时候，可能会出现连锁更新问题

6.0开始用listpack结构替换了ziplist

ziplist的数据结构：

zlbytes  zltail  zllen   entry...entry zlend

zlbytes：4个字节存整个ziplist占的总字节数

zltail：4个字节存整个zltail占的总字节数

zllen：2个字节  也就是元素个数，所以一个ziplist最多存储2的16次方-1个元素

zlend：始终是255用来标识整个链表结束

entry：分为prevlen，len，data

prevlen：靠prevlen确定往前多少个字节就能拿到一个entry首地址。采用变长编码，如果前一个entry长度<254字节，用一个1字节就可以存下，如果>255，当前entry需要5个字节，这5个字节里面第一个字节存254，剩余4个字节存长度。

len：也是变长编码。

zipList：每次如果空间不够，就要去扩容很麻烦，所以我们加上双端链表来解决这个问题

3.2 版本前，redis采用ziplist和linkedlist来实现，当元素个数小于512个元素大小小于64字节时，用ziplist编码，超过则用linkedlist编码

3.2 版本后，用quicklist编码

![1684682492577](H:\面试资料\11、redis问题\1684682492577.png)

## 十、Set

1、set用的是一种有序的数据结构去做的，用的是value为null的一个字典

2、如果全是int，那么就是intset（是有序的，其实就是一个结构体里面有个数组）

（1）redis会确保intset中的数据唯一

（2）具备升级机制，可以节省内存空间

（3）底层采用2分查找法来查询

3、如果有非整形，或者数据量特别多，就是hashtable

set-max-intset-entries 512这个我们可以配置

## 十一、Hash数据类型

底层是一个字典（dict），用k-v来存储，当数据量比较小的时候用ziplist来存储，他是一个元素key-value拆成两个相邻的元素元素存在ziplist里面的

hash-max-ziplist-entries  512 （元素个数超过512用hashtable编码）

hash-max-ziplist-value  64  （单个元素大小超过64byte用hashtable编码）

## 十二、ZSet

底层是字典+跳表，当元素比较少的时候用ziplist编码，当元素数量小于128的时候和每个元素大小都小于64个字节的时候

![1684684315009](H:\面试资料\11、redis问题\1684684315009.png)

用字典来保证key-value存储，用skiplist来排序。

跳表是怎样的数据结构：

最后一层存数据，上一层是索引，索引上面又是索引，插入和查找元素位置都是logN，一般上一层索引都是下一层索引的2分之一。用了跳表结构，每次插入，就不需要去访问On个元素了，最差是logN，提高了插入效率

