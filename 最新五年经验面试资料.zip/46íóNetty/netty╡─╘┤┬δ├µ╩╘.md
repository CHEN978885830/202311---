## 一、Netty中的Channel和JDK NIO包下的Channel的关系

1、Netty的Channel内部包装着一个JDK NIO包的一个Channel对象，并且会把他设置成非阻塞模式

## 二、bootstrap的连接过程

1、他有些东西需要我们去配置例如（1）工作线程池，（2）Netty Channel实现类Class（2）还有pipeline

2、通过反射创建出来NettyChannel对象

3、初始化Channel内部的pipeline，把bootstrap上配置的处理单元装载到Channel内部的pipeline管道中

4、把channel注册到EventGroup中

## 三、channel注册到EventLoop中做了什么事情？

他底层做了一件事情，就是将Netty Channel对象维护的JDK NIO Channel注册到NioEventLoop的Selector对象内

## 四、如何理解NioEventLoop

1、他不仅仅是个线程，他是非常复杂的，他是要处理io事件的，他也可以处理普通任务

2、NioEventLoop内，一定持有selector对象，用来监听socket

3、他底层做了一件事情，就是将Netty Channel对象维护的JDK NIO Channel注册到NioEventLoop的Selector对象内

## 五、