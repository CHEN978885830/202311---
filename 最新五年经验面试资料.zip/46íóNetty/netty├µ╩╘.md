## 一、对netty的理解

1、他是一个基于高性能NIO网络通信模型的框架，是对nio网络通信模型的封装，提供了简单易用的api，我们可以利用这些封装好的api去快速开发网络程序

2、Netty在nio的基础上做了很多优化，例如零拷贝机制，高性能无锁队列，内存池，性能比nio更高

3、netty可以支持多种通信协议，比如说http，websocket，并且针对数据通信拆包黏包一些问题，netty内置了拆包策略。

## 二、为什么要使用netty

netty相比于使用nio自带的api来说更加简单，统一的api，1、他支持多种传输类型，阻塞，非阻塞以及epoll，poll模型，

2、我们可以使用非常少的代码去实现多线程Reactor模型，以及多线程主从Reactor模型

3、自带编解码器，去解决tcp拆包黏包的问题

4、自带各种通信协议

5、netty相比于直接使用nioapi，提供了更高的吞吐量，更低的延迟，更低的资源消耗和更少的内存复制

6、安全性很好他有完整的SSL/TLS的支持

7、社区很活跃版本迭代很稳定

## 三、用netty可以去解决什么事情

1、传统的bio模型无法承载多用户同时访问的问题，使得他无法支持更高的连接数和吞吐量

2、NIO去实现多路复用模型，他可以在连接数方面做到优化，但是api使用比较复杂

3、netty是基于NIO的封装，提供了简单易用的api，降低了使用成本和学习成本

## 四、Netty里面有哪些核心组件

1、网络通信层：Bootstrap、ServerBootStrap、Channel。

Bootstrap负责客户端的启动去连接服务端

ServerBootStrap负载服务端的监听

Channel是负责网络通信的一个载体

2、事件调度器：EventLoopGroup与EventLoop

一般是bossGroup负责接收客户端请求，一般只需要创建一个线程即可

workerGroup用来处理具体业务，可以多创建几个充分利用cpu

3、服务编排层：channelPipeline，ChanelHandler，ChannelHandlerContext

channelPipeline：他负责处理多个ChannelHandler，他负责把多个channelHandler构成一个链

channelHandler：主要是针对io数据的一个处理器，数据接收后通过指定的handler进行处理

channelHandlerContext：用来保存channelHandler的上下文信息，拿着真正的channel

## 五、Netty里面有哪几种线程模型

1、单线程单Reactor模型：

单个线程去处理，接收客户端的连接时间，根据事件类型分发给不同的处理器进行处理

缺点：一个handler阻塞，会导致后面的连接无法被处理

2、多线程单Reactor模型：

所有的io操作都是由一个reactor来完成的，接收到请求后根据事件，分发给不同的处理器进行处理，期间可以用线程池来处理数据

缺点：这样会导致单个reactor会出现一些性能瓶颈，对小容量场景性能影响不是很大，但是对于高并发场景，很容易因为单reactor阻塞带来并发量的一个下降，当线程处理超过负载以后，处理的速度会变慢，会导致大量的连接超时

3、多线程多Reactor模型：主从多线程Reactor模型

他是通过MainReactor负责接收客户端的连接请求，然后传递给subReactor，具体的事件的io处理由subReactor来完成，最终去绑定给对应的handler

## 六、讲一下Reactor模型

1、Reactor：负责将io事件分派给handler

2、Acceptor：处理客户端的连接请求

3、handler：去执行业务逻辑读写操作